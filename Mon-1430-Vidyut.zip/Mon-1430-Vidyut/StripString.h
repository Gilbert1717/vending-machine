#ifndef STRIP_STRING_H
#define STRIP_STRING_H

#include <iostream>
#include <string>


// Modified version of split string function I(Vidyut) made for assignment 1(in the helper class)
class StripString
{
private:
public:
    // Strip leading and trailing whitespace from string
    static void stripString(std::string* s);

};

#endif